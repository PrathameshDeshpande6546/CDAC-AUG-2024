﻿namespace _003DemoMVC.Models
{
    public class Book
    {
        public int ISBN { get; set; }
        public string Title { get; set; }
    }
}
