﻿
using System.Data.SqlClient;
using System;

namespace HelloCSharp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 100;
            Console.WriteLine(i);
            Console.WriteLine("Hello C#");
            Console.ReadLine();
        }
    }
}
