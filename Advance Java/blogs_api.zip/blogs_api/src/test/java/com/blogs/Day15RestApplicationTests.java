package com.blogs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day15RestApplicationTests {

	@Test
	void contextLoads() {
	}

}
