package com.blogs.pojos;

public enum UserRole {
	ADMIN, BLOGGER
}
