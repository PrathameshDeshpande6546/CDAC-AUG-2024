package com.cdac.entities;

public enum UserRole {
	ADMIN, BLOGGER, COMMENTER, MANAGER
}
